class Marienbad {
    void principal(){
         //test_gagnant();
         //test_somme();
         //test_tableauStratGagnante();
         //test_tableau_binaire();
         //test_stratGagnant();
         //test_plusAlu();
         //test_calculAlu();
         //test_calcul_binaire();
         //test_saisie_tableau();
         //test_ordinateur();
         String j1 = SimpleInput.getString("Quelle est le nom de joueur 1? ");
         String j2 = "Ordinateur";
         int[]alu = saisie_tableau();
         boolean tour = SimpleInput.getBoolean("Voulez vous que le joueur 1 commence ?");
         boolean j = jeux(alu, j1, j2,tour);
         
         gagnant (j, j1, j2);
        }
     /**
     * trouve qu'elle strategie employé par l'ordinateur et l'éxecute
     * @param t tableau a afficher
     */
     void ordinateur(int[]t){
         boolean pair = 
         stratGagnant(tableauStratGagnante(calcul_binaire(t)));
         int iplus = plusAlu(t);
         int choix = calculAlu(t, iplus);
         if(pair){
             int ranger = (int) (Math.random()*t.length);
             if (t[ranger] == 0){
                 ranger = (int) (Math.random()*t.length);
                }
             int choixPair = (int) (Math.random()*t[ranger]);
             while (choixPair == 0){
                 choixPair = 1;
                }                                
             t[ranger] = t[ranger] - choixPair;
            }else{       
                 t[iplus] = t[iplus] - choix;
                }
        }
    
     /**
     * Teste la méthode ordinateur()
     */
    void test_ordinateur () {
        System.out.println ();
        System.out.println ("*** test_ordinateur()");
        //cas normaux
        int [] tableau = {1,3,5,7};
        testCasOrdinateur (tableau, false);
        int [] tab = {0,3,5,7};
        testCasOrdinateur (tab, true);
        //cas limite

        //cas erreur
        //int[]t = null;
        //testCasOrdinateur (t, false);
       }
    /**
    * teste un appel de ordinateur
    * @param a tour du joueur gagnant
    * @param j1 nom du joueur 1
    * @param j2 nom du joueur 2
    * @param result resultat attendu
    **/
    void testCasOrdinateur (int[]t, boolean result) {
         // Arrange
            System.out.println
            ("Apres le tour de l'ordinateur avec comme plateau: ");
            affiche_tableau(t);
            System.out.print
            ("On passe a une strategie ");
            if (result == true){
                System.out.println ("paire: ");
            }else{
                System.out.println ("impaire: ");
                }
         // Act
         ordinateur(t);
         boolean resExec = stratGagnant(tableauStratGagnante(calcul_binaire(t)));
         // Assert
         if (result = resExec){
             System.out.println ("OK");
            } else {
                 System.err.println ("ERREUR");
                }
       }
     /**
     * calcul le nombre d'alumette a enlever pour etre en strategie pair
     * @param t tableau a afficher
     * @return le nombre d'alumette a enlever
     */
     int calculAlu(int[]t, int iplus){
         double choixd = 0; 
         int choix;
         int[] bin = tableauStratGagnante(calcul_binaire(t));
         for(int i = 0;i < bin.length;i++){
             if(bin[i]%2 != 0){
                 choixd = choixd + Math.pow(2,bin.length-1-i);
               }
           }
         if(t[iplus] > (int) choixd){
             choix = t[iplus] - (int) choixd;
            }else if(t[iplus] < (int) choixd){
                 choix = (int) choixd - t[iplus];
                }else{
                     choix = (int) choixd;
                    }
         System.out.println(choix);
        return choix;
        }

     /**
     * Teste la méthode calculAlu()
     */
     void test_calculAlu () {
         System.out.println ();
         System.out.println ("*** test_gagnant()");
         //cas normaux
         int [] t1 = {0,3,5,7};
         testCasCalculAlu (t1, 3, 6);
         int [] t2 = {1,3,5,7};
         testCasCalculAlu (t2, 3, 7);
         //cas limite
         int [] t3 = {0,3,5,7};
         testCasCalculAlu (t3, 2, 4);
         //cas d'erreur
         int [] t4 = {0,3,5,7};
         //testCasCalculAlu (t4, 5, 1);
         int [] t5 = null;
         //testCasCalculAlu (t5, 3, 1);
        }
     /**
     * teste un appel de gagnant
     * @param a tour du joueur gagnant
     * @param j1 nom du joueur 1
     * @param j2 nom du joueur 2
     * @param result resultat attendu
     **/
     void testCasCalculAlu (int[]t, int iplus, int result) {
         // Arrange
         System.out.print ("Pour ");
         affiche_tableau(t);
         System.out.print ("on doit enlever "+result+" a l'indice "+iplus+" pour atteindre une strategie pair: ");
         // Act
         int resExec = calculAlu(t, iplus);
         // Assert
         if (result == resExec){
             System.out.println ("OK");
         }else {
             System.err.println ("ERREUR");
            }
        }
     /**
     * trouve a quelle index d'un tableau il y a le nombre le plus grand
     * @param t tableau a afficher
     * @return l'index du tableau ou il y a le plus grand nombre
     */
     int plusAlu (int[]t){
         int res = 0;
         for(int i = 1;i < t.length;i++){
             if(t[i] > t[res]){
                 res = i;
             }
         }
         return res;
        }
     /**
     * Teste la méthode plusAlu()
     */
        void test_plusAlu () {
            System.out.println ();
            System.out.println ("*** test_gagnant()");
            //cas normaux
            int [] t1 = {1,3,5,7};
            testCasPlusAlu (t1, 3);
            int [] t2 = {50,1,25,0};
            testCasPlusAlu (t2, 0);
            //cas limite

            //cas d'erreur
            int [] t4 = {0,3,5,7};
            //testCasCalculAlu (t4, 5, 1);
            int [] t5 = null;
            //testCasCalculAlu (t5, 3, 1);
           }
        /**
        * teste un appel de gagnant
        * @param t tour du joueur gagnant
        * @param result nom du joueur 1
        **/
        void testCasPlusAlu (int[]t, int result) {
            // Arrange
            System.out.print ("La valeur la plus grande pour ");
            affiche_tableau(t);
            System.out.print ("est situer a l'index "+result+" : ");
            // Act
            int resExec = plusAlu(t);
            // Assert
            if (result == resExec){
                System.out.println ("OK");
            }else {
                System.err.println ("ERREUR");
               }
           }
     /**
     * Calcule si la strategie gagnante est paire ou non
     * @param t tableau contenant la strategie gagnante
     * return vrai si paire et faux si impaire
     */
     boolean stratGagnant(int[] t){
         boolean win = true;
         for(int i = 0;i<t.length && win;i++){
             if(t[i]%2 == 0){
                 win = true;
                }else{
                    win = false;
                    }
            }
         return win;
        }
     /**
     * Teste la méthode stratGagnant()
     */
        void test_stratGagnant () {
            System.out.println ();
            System.out.println ("*** test_gagnant()");
            //cas normaux
            int [] t1 = {2, 2, 4};
            testCasStratGagnant (t1, true);
            int [] t2 = {2, 2, 3};
            testCasStratGagnant (t2, false);
            //cas limite
            int [] t3 = {0};
            testCasStratGagnant (t3, true);
            //cas d'erreur
            int [] t4 = {0,3,5,7};
            //testCasCalculAlu (t4, 5, 1);
            int [] t5 = null;
            //testCasCalculAlu (t5, 3, 1);
           }
        /**
        * teste un appel de stratGagnant
        * @param t tour du joueur gagnant
        * @param result nom du joueur 1
        **/
        void testCasStratGagnant (int[]t, boolean result) {
            // Arrange
            affiche_tableau(t);
            System.out.print (" signifie une strategie ");
            if (result){
                System.out.print ("gagnante: ");
                }else{
                     System.out.print ("perdante: ");
                    }
            // Act
            boolean resExec = stratGagnant(t);
            // Assert
            if (result == resExec){
                System.out.println ("OK");
            }else {
                System.err.println ("ERREUR");
               }
           }
     /**
     * créer un tableau contenant la version binaire des nombre contenu
     * @param t tableau a afficher
     * @return le tableau de binaire
     */
     String[] tableau_binaire (int[]t){
         String[]tb = new String[t.length];
         for(int i =0;i<t.length;i++){
             tb[i]= Integer.toBinaryString(t[i]);
            }
         return tb;
        }
    /**
     * Teste la méthode tableau_binaire()
     */
        void test_tableau_binaire () {
            System.out.println ();
            System.out.println ("*** test_tableau_binaire()");
            //cas normaux
            int [] t1 = {2, 2, 4};
            String[] s1= {"10", "10", "100"};
            testCasTableau_binaire (t1, s1);
            int [] t2 = {2, 2, 3};
            String[] s2= {"10", "10", "11"};
            testCasTableau_binaire (t2, s2);
            //cas limite
            int [] t3 = {0};
            String[] s3= {"0"};
            testCasTableau_binaire (t3, s3);
            //cas d'erreur;
           }
        /**
        * teste un appel de gagnant
        * @param t tour du joueur gagnant
        * @param result nom du joueur 1
        **/
        void testCasTableau_binaire (int[]t, String[] result) {
            // Arrange
            affiche_tableau(t);
            System.out.print (" devient en binaire ");
            affiche_tableauS(result);
            System.out.print (" : ");
            // Act
            String[] resExec = tableau_binaire(t);
            boolean verif = verifTabS(result, resExec);
            // Assert
            if (verif){
                System.out.println ("OK");
            }else {
                System.err.println ("ERREUR");
               }
           }
     /**
     * Decompose un entier en chiffre
     * @param a Entier a decomposé
     * @result tableau contenant l'entier decomposé
     */
     int []tableauStratGagnante(int a){
         String strat = String.valueOf(a);
         int[] stratNum = new int[strat.length()];
         for(int i = 0;i<strat.length();i++){
             stratNum[i] = Character.digit(strat.charAt(i), 10);
            }
         return stratNum;
        }
     /**
     * Teste la méthode tableauStratGagnante()
     */
     void test_tableauStratGagnante () {
         System.out.println ();
         System.out.println ("*** test_tableauStratGagnante()");
         //cas normaux
         int [] t1 = {2,2,4};
         testCasTableauStratGagnante (224, t1);
         int [] t2 = {0};
         testCasTableauStratGagnante (0, t2);
         //cas limite

         //cas d'erreur
        }
     /**
     * teste un appel de TableauStratGagnante()
     * @param a Entier a decomposé
     * @param resultat resultat attendu
     **/
     void testCasTableauStratGagnante (int a, int[]resultat) {
         boolean verif = true;
         // Arrange
             System.out.print
             ("L'entier " + a + " devient ");
             affiche_tableau(resultat);
             System.out.print
             (" :");
         // Act
         int[] resExec = tableauStratGagnante(a);
         // Assert
         for(int i =0;i < resExec.length && verif;i++){
             if(resExec[i] != resultat[i]){
                 verif = false;
             }
            }
         if (verif){
             System.out.println ("OK");
         } else {
             System.err.println ("ERREUR");
         }
        }
     /**
     * créé un tableau contenant l'addition de la version binaire d'un tableau
     * @param t tableau a afficher
     */
     int calcul_binaire (int[]t){
         int a = 0;
         String[]tb = tableau_binaire(t);
         for (int i = 0;i<tb.length;i++){
             a = a + Integer.parseInt(tb[i]);
            }
         return a;
        }
     
     /**
     * Teste la méthode calculBinaire()
     */
    void test_calcul_binaire () {
        System.out.println ();
        System.out.println ("*** test_calcul_binaire()");
        //cas normaux
        int [] t1 = {1, 3, 5, 7};
        testCasCalcul_binaire (t1, 224);
        int [] t2 = {0};
        testCasCalcul_binaire (t2, 0);
        //cas limite

        //cas d'erreur
       }
    /**
    * teste un appel de TableauStratGagnante()
    * @param a Entier a decomposé
    * @param resultat resultat attendu
    **/
    void testCasCalcul_binaire (int[]t, int result) {
        // Arrange
            affiche_tableau(t);
            System.out.print
            ("devient l'entier " + result + ": ");
        // Act
        int resExec = calcul_binaire(t);
        // Assert
        if (result == resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
     /**
     * Affiche le gagnant du jeu
     * @param a tour du joueur gagnant
     * @param j1 nom du joueur 1
     * @param j2 nom du joueur 2
     * @return vrai si le joueur 1 a gagné et faux si le joueur 2 a gagné
     **/
     boolean gagnant (boolean j, String j1, String j2){
         if (j == true){
             System.out.println(j2+ " a gagner!");
             j = false;
            }else{
                 System.out.println(j1+ " a gagner!");
                 j = true;
                }
         return j;
        }
     /**
     * Teste la méthode gagnant()
     */
     void test_gagnant () {
         System.out.println ();
         System.out.println ("*** test_gagnant()");
         testCasgagnant (true, "joueur 1", "joueur 2", false);
         testCasgagnant (false, "joueur 1", "joueur 2", true);
         
        }
     /**
     * teste un appel de gagnant
     * @param a tour du joueur gagnant
     * @param j1 nom du joueur 1
     * @param j2 nom du joueur 2
     * @param result resultat attendu
     **/
     void testCasgagnant (boolean a, String j1, String j2, boolean result) {
         // Arrange
         if (a ==false){
             System.out.print
             ("(\"" + j1 + "\") est le gagnant : ");
            }else{
                 System.out.print
                 ("(\"" + j2 + "\") est le gagnant : ");
                }
         // Act
         boolean resExec = gagnant(a, j1, j2);
         // Assert
         if (resExec == result){
             System.out.println ("OK");
         } else {
             System.err.println ("ERREUR");
         }
        }

     /**
     * Lancement du jeu de marienbad
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     boolean jeux (int[]alu, String j1, String j2, boolean tour){
         while (somme(alu) !=0){
             if (tour == true){
                 System.out.println("Tour du joueur: "+j1);
                 affiche_alumette(alu);
                 choix(alu);
                 tour = false;
                }else{
                     System.out.println("Tour de l'ordinateur");
                     affiche_alumette(alu);
                     ordinateur(alu);
                     tour = true;
                    }
            }
         return tour;
        }
    
    /**
     * Teste la méthode jeux()
     */
    void test_jeux () {
        System.out.println ();
        System.out.println ("*** test_jeux()");
        //cas normaux
        int [] t1 = {1, 3, 5, 7};
        testCasjeux (t1, "Joueur du grenier", "Infogramme", true);
        
       }
    /**
    * teste un appel de gagnant
    * @param a tour du joueur gagnant
    * @param j1 nom du joueur 1
    * @param j2 nom du joueur 2
    * @param result resultat attendu
    **/
    void testCasjeux (int[]alu, String j1, String j2, boolean tour) {
            System.out.println
            ("Le jeux ce lance : ");
        // Act
        jeux(alu, j1, j2, tour);
        boolean resExec = SimpleInput.getBoolean("Est ce que le jeu c'est bien lancé ?");
        // Assert
        if (resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
    
     /**
     * Saisie du nombre de ranger d'alumette
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     int[]saisie_tableau(){
         int a = SimpleInput.getInt("Combien de ranger voulez vous ? ");
         int[]t = new int[a];
         for (int i =0;i < a;i++){
             t[i]= 1 + i*2;
            }
         return t;
        }
    
     /**
     * Teste la méthode saisie_tableau()
     */
    void test_saisie_tableau () {
        System.out.println ();
        System.out.println ("*** test_saisie_tableau()");
        //cas normaux
        int [] t1 = {1, 3, 5, 7};
        testCasSaisie_tableau (4, t1);
        
       }
    /**
    * teste un appel de gagnant
    * @param a tour du joueur gagnant
    * @param j1 nom du joueur 1
    * @param j2 nom du joueur 2
    * @param result resultat attendu
    **/
    void testCasSaisie_tableau (int prerequis, int[]result) {
        //Arrange
        System.out.println ("Entrer "+prerequis);
        int[] resExec = saisie_tableau();
        affiche_tableau(result);
        System.out.println (" est saisie:  ");
        // Act
        // Assert
        if (verifTab(result, resExec)){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
     /**
     * Affiche les alumette par rangé
     * @param t le tableau qui contient le nombre d'alumette par ranger
     */
     void affiche_alumette(int[]t){
         int a = 0;
         for(int i =0;i < t.length;i++){
             System.out.print(i+ "/ ");
             for(int id = 0;id < (t[a]);id++){
                 System.out.print("| ");
             }
             System.out.println("");
             a++;
            }
        }

     /**
     * Teste la méthode saisie_tableau()
     */
    void test_affiche_alumette () {
        System.out.println ();
        System.out.println ("*** test_saisie_tableau()");
        //cas normaux
        int [] t1 = {1, 3, 5, 7};
        testCasaffiche_alumette (4, t1);
        
       }
    /**
    * teste un appel de gagnant
    * @param a tour du joueur gagnant
    * @param j1 nom du joueur 1
    * @param j2 nom du joueur 2
    * @param result resultat attendu
    **/
    void testCasaffiche_alumette (int a, int[]t) {
        //Arrange
        System.out.println ("Est-ce qu'un tableau de jeux equivalent a ");
        affiche_tableau(t);
        boolean resExec = SimpleInput.getBoolean(" ?");
        // Assert
        if (resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
     /**
     * Saisi des allumette a prendre
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     void choix(int[] t){
         int r = 2;
         int a = 1;
         boolean h = false;
         boolean p = false;
         
         while (p == false){
             p = true;
             while (h == false){
                 r = SimpleInput.getInt
                 ("Quelle ranger choisisser vous ? ");
                 if (r >=0 && r <=t.length-1){
                     h = true;
                    }
                }
             h = false;
            while (!h && p){
                 a = SimpleInput.getInt
                 ("Combien d'alumette prenez vous ? ");
                 if (a >0 && a <= t[r]){
                     h = true;
                    }else{
                         p = false;
                         System.out.println
                         ("Vous avez saisie un nombre invalide d'alumettes. ");
                        }
                }   
            }
         t[r] = t[r]-a;
        }

     /**
     * Teste la méthode combinaison()
     **/
    void test_choix () {
        int[]t1 = {1,3,5,7};
        int[]t2 = {1,3,5,0};

        System.out.println ();
        System.out.println ("*** test_choix()");
        testCaschoix (t1, t2, 7);
       }
    /**
    * teste un appel de parfait
    * @param t tableau a additioner
    * @param result resultat attendu
    **/
    void testCaschoix (int[]t1, int[]t2, int a) {
        // Arrange
        System.out.print
        ("Selectionner "+a+":");
        // Act
         choix(t1);
         affiche_tableau(t2);
         boolean resExec = SimpleInput.getBoolean("Le nombre d'alumette correspondant a été enlevé");
        if (resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
     /**
     * Teste la méthode combinaison()
     **/
     void test_somme () {
         int[]t = {1,3,5,7};
         int[]ta = {1,2,3,4,5,6,7,8,9,10};
         System.out.println ();
         System.out.println ("*** test_gagnant()");
         testCassomme (t, 16);
         testCassomme (ta, 55);
         
        }
     /**
     * teste un appel de parfait
     * @param t tableau a additioner
     * @param result resultat attendu
     **/
     void testCassomme (int[]t, int result) {
         // Arrange
         System.out.print
         ("La somme du tableau est de " +result+" : ");
         // Act
         int resExec = somme(t);
         // Assert
         if (resExec == result){
             System.out.println ("OK");
         } else {
             System.err.println ("ERREUR");
         }
        }
     /**
     * Addition des valeurs d'un tableau
     * @param t tableau a additioner
     * @return la somme total du tableau
     */
     int somme (int[]t){
         int sm = 0;
         for(int i = 0; i < t.length;i++){
             sm = sm + t[i];
            }
         return sm;
        }
     
     /**
     * Affiche un tableau
     * @param t tableau a afficher
     */
     void affiche_tableau (int[]t){
         int i = 0;
         System.out.print("Le tableau {");
            while(i<t.length-1){
             System.out.print(t[i]+", ");
             i++;
            }
         System.out.println(t[i]+ "}");
     }

     /**
     * Teste la méthode affiche_tableau()
     **/
    void test_affiche_tableau () {
        int[]t = {1,3,5,7};
        int[]ta = {1,2,3,4,5,6,7,8,9,10};
        System.out.println ();
        System.out.println ("*** test_gagnant()");
        testCasAffiche_tableau (t);
        testCasAffiche_tableau (ta);
        
       }
    /**
    * teste un appel de affiche_tableauS()
    * @param t tableau a additioner
    * @param result resultat attendu
    **/
    void testCasAffiche_tableau (int[]t) {
        // Act
        affiche_tableau(t);
        boolean resExec = SimpleInput.getBoolean(" a t-il ete afficher ? ");
        // Assert
        if (resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }

     void affiche_tableauS (String[] t){
        int i = 0;
        System.out.print("Le tableau {");
           while(i<t.length-1){
            System.out.print(t[i]+", ");
            i++;
           }
         System.out.println(t[i]+ "}");
        }

     /**
     * Teste la méthode affiche_tableauS()
     **/
    void test_affiche_tableauS () {
        String[]t1 = {"coucou", "tout","le", "monde"};
        System.out.println ();
        System.out.println ("*** test_gagnant()");
        testCasAffiche_tableauS (t1);
        
       }
    /**
    * teste un appel de affiche_tableauS()
    * @param t tableau a additioner
    * @param result resultat attendu
    **/
    void testCasAffiche_tableauS (String[]t) {
        // Act
        affiche_tableauS(t);
        boolean resExec = SimpleInput.getBoolean(" a t-il ete afficher ? ");
        // Assert
        if (resExec){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }

     boolean verifTabS (String[]t1, String[]t2){
         boolean res = true;
         if(t1.length == t2.length){
             for (int i = 0;i < t1.length && res;i++){
                 if (!t1[i].equals(t2[i])){
                     res = false;
                    }
                }
            }else{
                 res = false;
                }
         return res;  
        }

     /**
     * Teste la méthode verifTabS()
     **/
    void test_verifTabS () {
        String[]t1 = {"coucou", "tout","le", "monde"};
        String[]t2 = {"coucou", "tout","le", "monde"};
        String[]t3 = {"coucou"};
        System.out.println ();
        System.out.println ("*** test_gagnant()");
        testCasVerifTabS (t1, t2, true);
        testCasVerifTabS (t1, t3, false);
        
       }
     /**
     * teste un appel de affiche_tableauS()
     * @param t tableau a additioner
     * @param result resultat attendu
     **/
     void testCasVerifTabS (String[]t1, String[]t2, boolean result) {
         //Arrange
         if(result){
             affiche_tableauS(t1);
             System.out.println ("et ");
              affiche_tableauS(t2);
             System.out.println (" sont identique: ");
            }else{
                 affiche_tableauS(t1);
                 System.out.println ("et ");
                 affiche_tableauS(t2);
                 System.out.println (" ne sont pas identique: ");
                }
        // Act
        boolean resExec = verifTabS(t1, t2);
        // Assert
        if (resExec == result){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }

     boolean verifTab (int[]t1, int[]t2){
         boolean res = true;
         if(t1.length == t2.length){
             for (int i = 0;i < t1.length && res;i++){
                 if (t1[i] != t2[i]){
                     res = false;
                    }
                }
            }else{
                 res = false;
                }
         return res;  
        }
     
     /**
     * Teste la méthode verifTabS()
     **/
    void test_verifTab () {
        int[]t1 = {0,1,2,3,4,5};
        int[]t2 = {0,1,2,3,4,5};
        int[]t3 = {0};
        System.out.println ();
        System.out.println ("*** test_gagnant()");
        testCasVerifTab (t1, t2, true);
        testCasVerifTab (t1, t3, false);
        
       }
     /**
     * teste un appel de affiche_tableauS()
     * @param t tableau a additioner
     * @param result resultat attendu
     **/
     void testCasVerifTab (int[]t1, int[]t2, boolean result) {
         //Arrange
         if(result){
             affiche_tableau(t1);
             System.out.println ("et ");
              affiche_tableau(t2);
             System.out.println (" sont identique: ");
            }else{
                 affiche_tableau(t1);
                 System.out.println ("et ");
                 affiche_tableau(t2);
                 System.out.println (" ne sont pas identique: ");
                }
        // Act
        boolean resExec = verifTab(t1, t2);
        // Assert
        if (resExec == result){
            System.out.println ("OK");
        } else {
            System.err.println ("ERREUR");
        }
       }
        
    }

