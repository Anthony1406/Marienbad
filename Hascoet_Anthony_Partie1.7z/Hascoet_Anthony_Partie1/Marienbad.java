class Marienbad {
    void principal(){
         String j1 = SimpleInput.getString
         ("Quelle est le nom de joueur 1? ");
         String j2 = SimpleInput.getString
         ("Quelle est le nom de joueur 2? ");
         test_gagnant();
         test_somme();
         int[]alu = saisie_tableau();
         boolean j =jeux(alu, j1, j2);
         
         gagnant (j, j1, j2);
        }
     /**
     * Affiche le gagnant du jeu
     * @param a tour du joueur gagnant
     * @param j1 nom du joueur 1
     * @param j2 nom du joueur 2
     **/
     boolean gagnant (boolean j, String j1, String j2){
         String win;
         if (j == true){
             System.out.println(j2+ " a gagner!");
             j = false;
            }else{
                 System.out.println(j1+ " a gagner!");
                 j = true;
                }
         return j;
        }
     /**
     * Teste la méthode gagnant()
     */
     void test_gagnant () {
         System.out.println ();
         System.out.println ("*** test_gagnant()");
         testCasgagnant (true, "joueur 1", "joueur 2", false);
         testCasgagnant (false, "joueur 1", "joueur 2", true);
         
        }
     /**
     * teste un appel de gagnant
     * @param a tour du joueur gagnant
     * @param j1 nom du joueur 1
     * @param j2 nom du joueur 2
     * @param result resultat attendu
     **/
     void testCasgagnant (boolean a, String j1, String j2, boolean result) {
         // Arrange
         if (a ==false){
             System.out.print
             ("(\"" + j1 + "\") est le gagnant : ");
            }else{
                 System.out.print
                 ("(\"" + j2 + "\") est le gagnant : ");
                }
         // Act
         boolean resExec = gagnant(a, j1, j2);
         // Assert
         if (resExec == result){
             System.out.println ("OK");
         } else {
             System.err.println ("ERREUR");
         }
        }

     /**
     * Lancement du jeu de marienbad
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     boolean jeux (int[]alu, String j1, String j2){
         boolean tour = true;
         while (somme(alu) !=0){
             if (tour == true){
                 System.out.println("Tour du joueur 1: "+j1);
                 affiche_alumette(alu);
                 choix(alu);
                 tour = false;
                }else{
                     System.out.println("Tour du joueur 2: "+j2);
                     affiche_alumette(alu);
                     choix(alu);
                     tour = true;
                    }
            }
         return tour;
        }
    
     /**
     * Saisie du nombre de ranger d'alumette
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     int[]saisie_tableau(){
         int a = SimpleInput.getInt("Combien de ranger voulez vous ? ");
         int[]t = new int[a];
         for (int i =0;i < a;i++){
             t[i]= 1 + i*2;
            }
         return t;
        }
     /**
     * Affiche les alumette par rangé
     */
     void affiche_alumette(int[]t){
         int a = 0;
         for(int i =0;i < t.length;i++){
             System.out.print(i+ "/ ");
             for(int id = 0;id < (t[a]);id++){
                 System.out.print("| ");
             }
             System.out.println("");
             a++;
            }
        }
     /**
     * Saisi des allumette a prendre
     * Cette methode ne peut pas etre testé,
     * puisqu'elle neccessite l'intervention du joueur
     */
     void choix(int[] t){
         int r = 2;
         int a = 1;
         boolean h = false;
         boolean p = false;
         
         while (p == false){
             p = true;
             while (h == false){
                 r = SimpleInput.getInt
                 ("Quelle ranger choisisser vous ? ");
                 if (r >=0 && r <=3){
                     h = true;
                    }
                }
             h = false;
            while (h == false && p == true){
                 a = SimpleInput.getInt
                 ("Combien d'alumette prenez vous ? ");
                 if (a >0 && a <= t[r]){
                     h = true;
                    }else{
                         p = false;
                         System.out.println
                         ("Vous avez saisie un nombre invalide d'alumettes. ");
                        }
                }   
            }
         t[r] = t[r]-a;
        }
     /**
     * Teste la méthode combinaison()
     **/
     void test_somme () {
         int[]t = {1,3,5,7};
         int[]ta = {1,2,3,4,5,6,7,8,9,10};
         System.out.println ();
         System.out.println ("*** test_somme()");
         testCassomme (t, 16);
         testCassomme (ta, 55);
         
        }
     /**
     * teste un appel de parfait
     * @param t tableau a additioner
     * @param result resultat attendu
     **/
     void testCassomme (int[]t, int result) {
         // Arrange
         System.out.print
         ("La somme du tableau est de " +result+" : ");
         // Act
         int resExec = somme(t);
         // Assert
         if (resExec == result){
             System.out.println ("OK");
         } else {
             System.err.println ("ERREUR");
         }
        }
     /**
     * Addition des valeurs d'un tableau
     * @param t tableau a additioner
     */
     int somme (int[]t){
         int sm = 0;
         for(int i = 0; i < t.length;i++){
             sm = sm + t[i];
            }
         return sm;
        }
    }

